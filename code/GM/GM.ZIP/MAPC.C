/*----------------MAP specific routines--------------------------------*/
/* Andy Stone            JULY 2,1991                                   */
/* Last Edited: 7/2/91                                                 */
/*---------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include "scrnrout.h"
#include "mousefn.h"
#include "windio.h"
#include "map.h"
#define FALSE 0
#define TRUE 1
#define sign(x) ((x) > 0 ? 1:  ((x) == 0 ? 0:  (-1)))

int loadmap(void);
int savemap(void);

extern mapstruct       map[MWID][MLEN];
extern monmapstruct    mm[LASTMM];


static char ext[]=".map";
char mapcurfile[41]="map\\";

int loadmap(void)
  {
  FILE *fp;
  char fname[41]="map\\";
 
  if (!getfname(5,7,"Enter map file to load:",ext,fname)) return(FALSE);
  fp=fopen(fname,"rb"); /* must exist because getfname searches for it */
  fread( (char*) &map,sizeof(mapstruct),MLEN*MWID,fp);
  fread( (char*) &mm,sizeof(monmapstruct),LASTMM,fp); 
  fclose(fp);
  strcpy((char*)mapcurfile,(char*)fname);
  return(TRUE);
  }

int savemap()
  {
  FILE *fp;
  char fname[41];
  char fname1[41];
  int result=0;

  strcpy(fname,mapcurfile);
  for (result=0;result<strlen(fname); result++) /* Knock off extension */
    if (fname[result]=='.') fname[result]=0;   


  if (!qwindow(2,7,30,"Save map as:",fname)) return(FALSE);
  strcpy(fname1,fname);
  strcat (fname1,ext);

  if (strcmpi((char*)fname1,(char*)mapcurfile)!=0)
    {
    if ((fp=fopen(fname1,"rb"))!=NULL)
      {  /* file exists already, and is not current one */
      fclose(fp);
      result=errorbox("This file already exists! Saving now will destroy the old file!","(C)ontinue save    (D)o not save")&255;
      if ((result!='C')&(result!='c'))
        {
        return(FALSE);
        }
      }
    }

  fp=NULL;

  while (fp==NULL)
    {
    if ((fp=fopen(fname1,"wb"))==NULL)
      {
      result=errorbox("Unable to Save!","(E)xit (R)etry");
      result&=255;
      if ((result=='E')|(result=='e'))
        {
        return (FALSE);
        }
      }
    }

  fwrite( (char*) &map,sizeof(mapstruct),MLEN*MWID,fp);
  fwrite( (char*) &mm,sizeof(monmapstruct),LASTMM,fp); 
  fclose(fp);
  strcpy((char*)mapcurfile,(char*)fname1);
  return(TRUE);
  }
