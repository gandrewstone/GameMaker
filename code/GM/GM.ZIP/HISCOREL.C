#include <stdio.h>
#include <string.h>
#include <bios.h>
#include "windio.h"
#include "scrnrout.h"
#include "mousefn.h"

void checkhi(char *gamename,long int score);

typedef struct
 {
  long int sc;
  char yourname[30];
 } scorelist;

#pragma loop_opt(off)

void checkhi(char *gamename,long int score)
 {
  register int j,k;
  scorelist top[10];
  int mx,my,mbuts=0;
  char w[1000];
  int attr;
  char str[50];

  FILE *fp_in,*fp_out;
  char hifile[41];

  strcpy(hifile,gamename);
  for (j=0; ( (j<31)&(hifile[j]!='.')) ;j++); /* Find extension */ 
    hifile[j]=0;   /* Chop extension */
    
  strcat(hifile,".his");

  for (j=0;j<sizeof(scorelist)*10;j++)
    *( ((char *)&top[0])+j )=0;

  if ( (fp_in=fopen(hifile,"rb")) != NULL) 
    {
    fread( (char *)&top[0],sizeof(scorelist),10,fp_in);
    fclose(fp_in);
    }
  for (j=0;j<10;j++) {
    if (score>top[j].sc) { 
      for (k=9;k>j;k--) { top[k]=top[k-1]; }
      top[j].sc = score;
      attr = openmenu(24,5,27,4,w);
      writestr(24,5,attr+4,"     Congratulations!");
      sprintf(str," You have scored number %2d",j+1);
      writestr(24,7,attr+15,str);
      writestr(24,8,attr+15,"   on the Top Ten list!");
      top[j].yourname[0]=0;
      qwindow(13,15,29,"Enter Your Name: ",top[j].yourname);
      closemenu(24,5,27,4,w);
      break;
     }
   }

  if ( (fp_out=fopen(hifile,"wb")) == NULL) 
    errorbox(" Problem writing Top Score File","  (E)xit");
  else {
    fwrite( (char *)&top[0],sizeof(scorelist),10,fp_out);
    fclose(fp_out);
   }

  attr = openmenu(18,5,47,14,NULL);
  writestr(18,5,attr+4,"                Top Ten Scores");
  writestr(18,6,attr+15,"            �������");
  for (j=0;j<10;j++) {
    sprintf(str," %2d:%10ld � %s",j+1,top[j].sc,top[j].yourname);
    writestr(18,j+7,attr+15,str);
   }
  writestr(18,17,attr+15,"            �������");
  writestr(18,18,attr+15,"              Hit any key to exit");
//  closemenu(18,5,47,14,w);

  while ((!bioskey(1))&&(!mbuts))
    {
    #ifdef MOUSE
    moustats(&mx,&my,&mbuts);
    #endif
    }
  if (bioskey(1)) bioskey(0);
  }

#pragma loop_opt(on)
